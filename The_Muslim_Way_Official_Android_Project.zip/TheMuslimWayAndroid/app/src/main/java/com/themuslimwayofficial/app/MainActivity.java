package com.themuslimwayofficial.app;
import android.app.Activity; import android.os.Bundle; import android.webkit.*; import android.view.*; import android.content.*; import android.net.Uri;
public class MainActivity extends Activity {
  WebView web;
  @Override public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); setContentView(web); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,String u){ if(u.startsWith("http://")||u.startsWith("https://")||u.startsWith("tel:")||u.startsWith("mailto:")){ try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));}catch(Exception e){} return true;} return false; }}); web.loadUrl("file:///android_asset/index.html"); }
  @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
