# The Muslim Way Official — Android Project

Build-ready Android WebView wrapper for the supplied HTML prototype.

## Build APK
Open this folder in Android Studio, let Gradle sync, then use **Build > Build APK(s)**.

The generated debug APK will normally be under `app/build/outputs/apk/debug/`.

This project is not signed for Play Store production release; a release signing key is required for a production build.
